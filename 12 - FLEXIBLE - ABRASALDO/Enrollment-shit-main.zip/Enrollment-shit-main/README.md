<div align='center'>

<h1>Enrollment System</h1>
<p>for school project</p>

<h4> <span> · </span> <a href="https://github.com/CrLn-66/Enrollment-shit/blob/master/README.md"> Documentation </a> <span> · </span> <a href="https://github.com/CrLn-66/Enrollment-shit/issues"> Report Bug </a> <span> · </span> <a href="https://github.com/CrLn-66/Enrollment-shit/issues"> Request Feature </a> </h4>


</div>

# :notebook_with_decorative_cover: Table of Contents

- [About the Project](#star2-about-the-project)
- [Roadmap](#compass-roadmap)
- [License](#warning-license)


## :star2: About the Project

## :compass: Roadmap

* [x] Dashboard interface
* [x] Signin Interface
* [x] Signup Interface
* [ ] Admin Interface
* [ ] Profile Interface
* [ ] Dashboard live data analytics
* [ ] signup function
* [ ] signin function
* [ ] admin live confidential info view
* [ ] enrollment form


## :wave: Contributing

<a href="https://github.com/CrLn-66/Enrollment-shit/graphs/contributors"> <img src="https://contrib.rocks/image?repo=Louis3797/awesome-readme-template" /> </a>

Contributions are always welcome!

see `contributing.md` for ways to get started

### :scroll: Code of Conduct

Please read the [Code of Conduct](https://github.com/CrLn-66/Enrollment-shit/blob/master/CODE_OF_CONDUCT.md)

## :warning: License

Distributed under the no License. See LICENSE.txt for more information.
